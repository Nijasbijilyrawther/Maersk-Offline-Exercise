﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Maersk.Sorting.Api
{
    public class SortJobProcessor : ISortJobProcessor
    {
        private readonly ILogger<SortJobProcessor> _logger;

        //This static concurrent dictionary will act as a thread-safe database storing the sortjob's data for this use-case.
        public static ConcurrentDictionary<Guid, SortJob> jobStatusDictionary = new ConcurrentDictionary<Guid, SortJob>();

        public SortJobProcessor(ILogger<SortJobProcessor> logger)
        {
            _logger = logger;
        }

        public async Task<SortJob> Process(SortJob job)
        {
           
            jobStatusDictionary.GetOrAdd(job.Id, job);
            _logger.LogInformation("Processing job with ID '{JobId}'.", job.Id);
            var stopwatch = Stopwatch.StartNew();

            var output = job.Input.OrderBy(n => n).ToArray();
            await Task.Delay(10000); // NOTE: This is just to simulate a more expensive operation

            var duration = stopwatch.Elapsed;
            
            //Updating the job status
            job.Status = SortJobStatus.Completed;
            job.Output = output;
            job.Duration = duration;
            
            _logger.LogInformation("Completed processing job with ID '{JobId}'. Duration: '{Duration}'.", job.Id, duration);

            return job;
        }

        public SortJob? GetJob(Guid JobId)
        {
            var isJobAvailable = jobStatusDictionary.TryGetValue(JobId, out SortJob? sortJob);
            return isJobAvailable != false ? sortJob : null;
        }

        public List<SortJob> GetJobs()
        {
            return jobStatusDictionary.Values.ToList();
        }
    }
}
