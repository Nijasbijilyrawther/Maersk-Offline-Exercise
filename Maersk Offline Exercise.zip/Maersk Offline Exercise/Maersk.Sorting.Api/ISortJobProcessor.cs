﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Maersk.Sorting.Api
{
    public interface ISortJobProcessor
    {
        /// <summary>
        /// Sorts the given input array
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        Task<SortJob> Process(SortJob job);

        /// <summary>
        /// Gets all the jobs currently in the system
        /// </summary>
        /// <returns></returns>
        List<SortJob> GetJobs();

        /// <summary>
        /// Get a job based on the given jobId
        /// </summary>
        /// <param name="JobId"></param>
        /// <returns></returns>
        SortJob? GetJob(Guid JobId);


    }
}